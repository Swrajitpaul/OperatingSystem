/**
 * Assignment1.java
 * @author swrajit paul
 * @version 1.0
 */
public class Assignment1 {
	
	public static void main(String[] args) {
		
		Integer[] array = new Integer[100];
		
		for(int i = 0; i < array.length; i++) {
			array[i] = (int) Math.floor(Math.random() * 10000) + 1;
		}
		
		System.out.println("Unsorted Order");
		for(int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
		
		MergeSort mg = new MergeSort(array, 0, array.length-1);
		
		mg.start();
		
		try {
			mg.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("Sorted Order");
		
		for(int i = 0; i < array.length; i++) {
			System.out.println(array[i]);
		}
	}
}
