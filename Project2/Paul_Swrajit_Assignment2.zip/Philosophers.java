public class Philosophers extends Thread{
    
	private DiningPhilosophers dp;
    private int PhilNumber;
    
    public Philosophers (DiningPhilosophers diningp, int i){
        dp = diningp;
        PhilNumber = i;
    }
    
    public void run(){
        while (true){
            
            dp.takeChopsticks(PhilNumber);
            eat();
            dp.returnChopsticks(PhilNumber);
            
        }
    }
    
    public void eat() {
        try{
        	int sleeptime = (int) (7 * Math.random());
        	Thread.sleep(sleeptime * 1000);
        }catch (InterruptedException e){}
    }
}

