Compile simpleshell and run simpleshell but you must have OSProcess in your folder.
javac SimpleShell.java
then java SimpleShell